print("test script v1.0\n")

user_input = input("Type anything: ")
expected_word = "hello"
b = 

if expected_word in user_input.lower():
   print("Hello, how'd ya?")
else:
     print("whaaat?")
